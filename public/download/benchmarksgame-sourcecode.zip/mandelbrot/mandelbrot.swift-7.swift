/* The Computer Language Benchmarks Game
 https://salsa.debian.org/benchmarksgame-team/benchmarksgame/

 direct transliteration of Greg Buchholz's C program
 contributed by Isaac Gouy, fix by David Turnbull
 dispatching to multiple cores
 use SIMD operations 
 use early break when in shallow waters by Patrick Stein
 */

import Foundation
#if os(Linux)
import Dispatch
#endif

let width: Int = Int(CommandLine.arguments[1])!
let height      = width
let iterations  = 50

let linecount       = height
let linesize        = (width + 7) / 8
let outputsize      = linecount * linesize

let serialQueue     = DispatchQueue(label: "outputlinesaccess")
let serialGroup     = DispatchGroup()
var originalAddress = UnsafeMutableRawPointer.allocate(byteCount: outputsize,
                                                       alignment: 1)

let height_d        = Double(height)
let twodivwidth     = 2.0 / Double(width)
let dispatchGroup   = DispatchGroup()

let stdout = FileHandle.standardOutput

serialGroup.enter()
serialQueue.async {
    stdout.write("P4\n\(width) \(height)\n".data(using:.utf8)!)
    serialGroup.leave()
}
let startwritingoffset = linecount / 100

@inline(__always) func oneiteration(Zr:inout SIMD8<Double>,Zi:inout SIMD8<Double>,
                                    Cr:inout SIMD8<Double>,Ci:Double,
                                    Tr:inout SIMD8<Double>,Ti:inout SIMD8<Double>)
{
    Zi = 2.0 * Zr * Zi + Ci
    Zr = Tr - Ti + Cr
    Tr = Zr * Zr
    Ti = Zi * Zi
}

@inline(__always)
func mandelbrot(shallow:Bool,x:Int,Ci:Double,twodivwidth:Double) -> UInt8
{
    var Zr:SIMD8<Double> = .zero
    var Zi:SIMD8<Double> = .zero
    var Tr:SIMD8<Double> = .zero
    var Ti:SIMD8<Double> = .zero
    var Cr:SIMD8<Double> = .zero

    let thresholds  = SIMD8<Double>(repeating:4.0)
    let isTrue      = SIMDMask<SIMD8<Double.SIMDMaskScalar>>(repeating: true)
    let ramp:SIMD8<Int64> = [128,64,32,16,8,4,2,1]

    var cmpresult:SIMDMask<SIMD8<Double.SIMDMaskScalar>>

    for x2 in 0...7
    {
        Cr[x2] = Double(x+x2)
    }
    Cr = Cr * twodivwidth - 1.5

    if shallow
    {
        for _ in 0..<iterations/4
        {
            for _ in 0..<4
            {
                oneiteration(Zr:&Zr,Zi:&Zi,Cr:&Cr,Ci:Ci,Tr:&Tr,Ti:&Ti)
            }
            cmpresult = Tr + Ti .>= thresholds

            if cmpresult == isTrue
            {
                return 0
            }
        }
        oneiteration(Zr:&Zr,Zi:&Zi,Cr:&Cr,Ci:Ci,Tr:&Tr,Ti:&Ti)
        oneiteration(Zr:&Zr,Zi:&Zi,Cr:&Cr,Ci:Ci,Tr:&Tr,Ti:&Ti)
    }
    else
    {
        for _ in 0..<iterations
        {
            oneiteration(Zr:&Zr,Zi:&Zi,Cr:&Cr,Ci:Ci,Tr:&Tr,Ti:&Ti)
        }
    }


    cmpresult = Tr + Ti .< thresholds

    let reduced: SIMD8<Int64> = unsafeBitCast(cmpresult,to: SIMD8<Int64>.self)
    let summask: SIMD8<Int64> = ramp & reduced
    let byte  =   summask[0] +
                  summask[1] +
                  summask[2] +
                  summask[3] +
                  summask[4] +
                  summask[5] +
                  summask[6] +
                  summask[7]

    return UInt8(byte)
}

var counter = 0

for y in 0..<linecount
{
    dispatchGroup.enter()
    DispatchQueue.global().async
    {
        [y,counter] in

        var address = originalAddress + counter

        let Ci = (Double(2*y)/height_d - 1.0)
        var shallow = false
        for x in stride(from: 0, to: width, by: 8)
        {
            let byte = mandelbrot(shallow:shallow,
                                    x: x,
                                    Ci: Ci,
                                    twodivwidth: twodivwidth)
            address.storeBytes(of: byte, as: UInt8.self)
            address += 1
            shallow = byte == 0
        }
        dispatchGroup.leave()
    }
    counter += linesize
}

dispatchGroup.wait()
serialGroup.wait()
stdout.write(Data(bytesNoCopy: originalAddress,
                        count: outputsize,
                  deallocator: .none))
