/* The Computer Language Benchmarks Game
 https://salsa.debian.org/benchmarksgame-team/benchmarksgame/

 direct transliteration of Greg Buchholz's C program
 contributed by Isaac Gouy, fix by David Turnbull
 dispatching to multiple cores by Patrick Stein
 writing out file in chunks not in bytes by Patrick Stein
 calculating only what's needed by Patrick Stein
 */


import Foundation
#if os(Linux)
import Dispatch
#endif

let width: Int = Int(CommandLine.arguments[1])!
let height = width

let iter = 50, limit = 2.0

let linecount       = (height + 2) / 2
let linesize        = (width + 7) / 8
let outputsize      = linecount * linesize

typealias OutputLine = ContiguousArray<UInt8>
var outputbits:OutputLine = OutputLine(repeating:0, count: outputsize)

let height_d        = Double(height)
let twodivwidth     = 2.0 / Double(width)
let dispatchGroup   = DispatchGroup()
var counter         = 0

for y in 0..<linecount
{
    var address = counter
    counter += linesize

    dispatchGroup.enter()
    DispatchQueue.global().async
    {
        var Zr, Zi, Cr, Ci, Tr, Ti: Double
        var byte_acc:UInt8  = 0
        var bit_num = 0
        Ci = 2.0*Double(y)/height_d - 1.0

        for x in 0..<width
        {
            Zr = 0.0; Zi = 0.0; Tr = 0.0; Ti = 0.0
            Cr = twodivwidth*Double(x) - 1.5;

            var i = 0
            while i < iter && (Tr+Ti <= limit*limit)
            {
                i += 1
                Zi = 2.0*Zr*Zi + Ci
                Zr = Tr - Ti + Cr
                Tr = Zr * Zr
                Ti = Zi * Zi
            }

            byte_acc <<= 1
            if Tr+Ti <= limit*limit { byte_acc |= 0x01 }

            bit_num += 1

            if bit_num == 8 {
                outputbits[address] = byte_acc
                address += 1
                byte_acc = 0
                bit_num = 0
            }
        }
        if bit_num != 0
        {
             byte_acc <<= (8-width%8)
             outputbits[address] = byte_acc
        }

        dispatchGroup.leave()
    }
}
dispatchGroup.wait()


let stdout = FileHandle.standardOutput

stdout.write("P4\n\(width) \(height)\n".data(using:.utf8)!)
stdout.write(Data(outputbits))

counter = height & 1 == 1 ? outputsize : outputsize - linesize

while counter > linesize
{
    counter -= linesize
    let data = Data(outputbits[counter..<counter+linesize])
    stdout.write(data)
}
