/* The Computer Language Benchmarks Game
   https://salsa.debian.org/benchmarksgame-team/benchmarksgame/

   Contributed by Isaac Gouy. Make time on each Isolate similar.
   calculateLine borrowed from Alexander Fyodorov's program. 
*/

import 'dart:async';
import 'dart:collection';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

final nIsolates = 4;

void main(List<String> args) {
  final mainIsolate = ReceivePort();
  final n = (args.length > 0) ? int.parse(args[0]) : 200;
  stdout.write('P4\n$n $n\n');

  var i = nIsolates;
  while (i-- > 0) {
    Isolate.spawn(other, mainIsolate.sendPort);
  }
  final requests = rowParameters(n);
  var awaited = requests.length;
  final ports = ListQueue<SendPort>();

  mainIsolate.listen((dynamic p) {
    if (p is SendPort) {
      ports.add(p);
      p.send(requests.removeFirst());
    } else {
      if (--awaited <= 0) {
        if (ports.isEmpty) {
          mainIsolate.close();
        } else {
          ports.removeFirst().send(1);
        }
      }
    }
  });
}

void other(SendPort p) {
  final otherIsolate = ReceivePort();
  p.send(otherIsolate.sendPort);

  var mandelbrot = <Uint8List>[];

  otherIsolate.listen((dynamic ini) async {
    if (ini is Parameters) {
      for (var y = ini.lo; y < ini.hi; y++) {
        mandelbrot.add(calculateLine(ini.n, y));
      }
      p.send(1);
    } else {
      await stdout.addStream(Stream.fromIterable(mandelbrot));
      p.send(0);
    }
  });
}

Uint8List calculateLine(int n, int y) {
  int lineLen = (n - 1) ~/ 8 + 1;

  var line = new Uint8List(lineLen);

  int xbyte = 0, bits = 1;
  double ci = y * 2.0 / n - 1.0;

  for (int x = 0; x < n; x++) {
    double cr = x * 2.0 / n - 1.5;
    if (bits > 0xff) {
      line[xbyte++] = bits;
      bits = 1;
    }
    double zr = cr, zi = ci, tr = cr * cr, ti = ci * ci;
    int i = 49;
    do {
      zi = zr * zi + zr * zi + ci;
      zr = tr - ti + cr;
      tr = zr * zr;
      ti = zi * zi;
    } while ((tr + ti <= 4.0) && (--i > 0));
    bits = (bits << 1) | (i == 0 ? 1 : 0);
  }
  while (bits < 0x100) bits = (bits << 1);
  line[xbyte] = bits;
  return line;
}

ListQueue<Parameters> rowParameters(int n) {
  const weights = [0.35, 0.5, 0.65];
  var lo = 0, w = 0;
  var p = ListQueue<Parameters>();
  for (var i = 0; i < weights.length; i++) {
    w = (weights[i] * n).floor();
    p.add(Parameters(lo, w, n));
    lo = w;
  }
  p.add(Parameters(w, n, n));
  return p;
}

class Parameters {
  var lo = 0, hi = 0, n = 0;
  Parameters(this.lo, this.hi, this.n);
}
