// The Computer Language Benchmarks Game
// http://benchmarksgame.alioth.debian.org/
//
// Alexandr Karbivnichiy

package main

import (
    "flag"
    "fmt"
//    "runtime/debug"
    "sort"
    "strconv"
    "sync"
)

type Tree struct {
    Left, Right *Tree
}

func createTree(depth int) *Tree {
    if depth > 0 {
        return &Tree{Left: createTree(depth - 1), Right: createTree(depth - 1)}
    } else {
        return &Tree{}
    }
}

func checkTree(tree *Tree) int {
    if tree.Left == nil {
        return 1
    }
    return 1 + checkTree(tree.Right) + checkTree(tree.Left)
}

func main() {
    n := 0
    flag.Parse()
    if flag.NArg() > 0 {
        n, _ = strconv.Atoi(flag.Arg(0))
    }
    run(n)
}

func run(maxDepth int) {
    const minDepth = 4
    var group sync.WaitGroup
    var messages sync.Map

    if minDepth+2 > maxDepth {
        maxDepth = minDepth + 2
    }

//    debug.SetGCPercent(500) // pace (GC allocations pressure)
    group.Add(1)
    go func() {
        tree := createTree(maxDepth + 1)
        fmt.Printf("stretch tree of depth %d\t check: %d\n",
            maxDepth+1, checkTree(tree))
        group.Done()
    }()
    group.Wait() // wait one thread for stretch, curb heap

    var longLivedTree *Tree
    group.Add(1)
    go func() {
        longLivedTree = createTree(maxDepth)
        group.Done()
    }()

    for halfDepth := minDepth / 2; halfDepth < maxDepth/2+1; halfDepth++ {
        depth := halfDepth * 2
        iterations := 1 << (maxDepth - depth + minDepth)
        group.Add(1)
        go func(d, i int) {
            chk := 0
            for i := 0; i < iterations; i++ {
                chk += checkTree(createTree(d))
            }
            messages.Store(d, fmt.Sprintf("%d\t trees of depth %d\t check: %d",
                i, d, chk))
            group.Done()
        }(depth, iterations)
    }

    group.Wait() // wait for all

    var idxs []int
    messages.Range(func(key, val interface{}) bool {
        idxs = append(idxs, key.(int))
        return true
    })
    sort.Ints(idxs)
    for _, idx := range idxs {
        msg, _ := messages.Load(idx)
        fmt.Println(msg)
    }

    fmt.Printf("long lived tree of depth %d\t check: %d\n",
        maxDepth, checkTree(longLivedTree))
}
